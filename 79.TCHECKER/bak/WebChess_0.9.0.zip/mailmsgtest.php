<?
	$mailsubject = "WebChess: Test Message";
	$mailmsg = "Congratulations!!!\n
	If you can see this message, you have successfully setup your email notification!\n\n
	This message has been automatically been sent by WebChess and should not be replied to.\n";
?>
