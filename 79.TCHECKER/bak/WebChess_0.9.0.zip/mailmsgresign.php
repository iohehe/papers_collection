<?
	$mailsubject = "WebChess: Opponent resigns";
	$mailmsg = "Your opponent ".$opponent." has resigned the game.";
	$mailmsg .= "\n\nThis message has been automatically been sent by WebChess and should not be replied to.\n";
?>
