<?
	$mailsubject = "WebChess: You've been invited to play a new game";
	$mailmsg = $opponent." has invited you to play a new game.";
	$mailmsg .= "\n\nThis message has been automatically been sent by WebChess and should not be replied to.\n";
?>
