<?
	$mailsubject = "WebChess: Your Move";
	$mailmsg = "Your opponent ".$opponent." has played the following move:";
	$mailmsg .= "\n".$move."\n\n";
	$mailmsg .= "\n\nThis message has been automatically been sent by WebChess and should not be replied to.\n";
?>
