<?
	$mailsubject = "WebChess: Invitation withdrawn";
	$mailmsg = $opponent." has withdrawn their invitation to play a new game.";
	$mailmsg .= "\n\nThis message has been automatically been sent by WebChess and should not be replied to.\n";
?>
