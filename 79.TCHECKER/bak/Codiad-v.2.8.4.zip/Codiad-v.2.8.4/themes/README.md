# Themes

The themes directory is where you place themes :-)
