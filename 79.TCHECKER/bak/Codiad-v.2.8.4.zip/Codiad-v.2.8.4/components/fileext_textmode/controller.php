<?php

/*
 *  (c) Codiad & ccvca (https://github.com/ccvca)
* @author ccvca (https://github.com/ccvca)
* This Code is released under the same licence as Codiad (https://github.com/Codiad/Codiad)
* See [root]/license.txt for more. This information must remain intact.
*/

require_once 'class.fileextension_textmode.php';

$fileExTM = new fileextension_textmode();


echo $fileExTM->processForms();
