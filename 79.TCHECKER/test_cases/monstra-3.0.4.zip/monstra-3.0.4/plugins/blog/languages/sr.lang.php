<?php
    return array(
        'blog' => array(
            'Blog' => 'Blog',
            'Blog plugin for Monstra' => 'Blog, dodatak za Monstra',
            'begin' => 'početak',
            'end' => 'kraj',
            'prev' => 'predhodna',
            'next' => 'sledeća',
        ) 
    );
