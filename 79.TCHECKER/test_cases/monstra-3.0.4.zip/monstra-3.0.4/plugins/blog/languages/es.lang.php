<?php

    return array(
        'blog' => array(
            'Blog' => 'Blog',
            'Blog plugin for Monstra' => 'Blog plugin for Monstra',
            'begin' => 'comienzo',
            'end' => 'final',
            'prev' => 'anterior',
            'next' => 'siguiente',
        ) 
    );
