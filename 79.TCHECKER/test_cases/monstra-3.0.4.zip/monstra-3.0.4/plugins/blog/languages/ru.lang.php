<?php

    return array(
        'blog' => array(
            'Blog' => 'Блог',
            'Blog plugin for Monstra' => 'Плагин блога для Monstra',
            'begin' => 'начало',
            'end' => 'конец',
            'prev' => 'назад',
            'next' => 'вперед',
            'Related posts' => 'Статьи по теме',
        ) 
    );