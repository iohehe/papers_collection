<?php

    return array(
        'filesmanager' => array(
            'Files' => 'Dateien',
            'Files manager' => 'Datei-Manager',
            'Name' => 'Name',
            'Actions' => 'Aktionen',
            'Delete' => 'Löschen',
            'Upload' => 'Hochladen',
            'directory' => 'Ordner',
            'Delete directory: :dir' => 'Lösche Ordner: :dir',
            'Delete file: :file' => 'Lösche Datei: file',
            'Extension' => 'Dateiendung',
            'Size' => 'Größe',
            'Select file' => 'Datei wählen',
            'Change' => 'Ändern',
        )
    );
