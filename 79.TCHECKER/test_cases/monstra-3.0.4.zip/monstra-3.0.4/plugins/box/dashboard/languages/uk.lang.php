<?php

    return array(
        'dashboard' => array(
            'Dashboard' => 'Dashboard',
            'Dashboard plugin for Monstra' => 'Dashboard пісочниця для Monstra',
            'Welcome back' => 'Добро пожаловать',
            'Create New' => 'Додати',
            'Upload File' => 'Завантажити файл',
        )
    );
