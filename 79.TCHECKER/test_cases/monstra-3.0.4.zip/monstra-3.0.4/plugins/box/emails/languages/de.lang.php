<?php

    return array(
        'emails' => array(
            'Emails' => 'Emails',
            'Emails plugin for Monstra' => 'Email Plugin für Monstra',
            'Edit Layout' => 'Bearbeite Layout',
            'Email templates' => 'Email Templates',
            'Edit' => 'Bearbeiten',
            'Edit Email Template' => 'Bearbeite Email Template',
            'Name' => 'Name',
            'Email template content' => 'Email Template Inhalt',
            'Save and Exit' => 'Speichern und Beenden',
            'Save' => 'Speichern',
            'Cancel' => 'Abbrechen',
            'This email template does not exist' => 'Dieses Email Template existiert nicht',
            'Your changes to the email template <i>:name</i> have been saved.' => 'Deine Änderung am Email Template <i>:name</i> wurden gespeichert.',
        )
    );
