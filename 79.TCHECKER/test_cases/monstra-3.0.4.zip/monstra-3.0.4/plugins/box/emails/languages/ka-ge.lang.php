<?php
    return array(
        'emails' => array(
            'Emails' => 'ელ-ფოსტები',
            'Emails plugin for Monstra' => 'პლაგინი ელ-ფოსტები Monstra-თვის',
            'Edit Layout' => 'ნიმუშის რედაქტირება',
            'Email templates' => 'წერილების ნიმუში',
            'Edit' => 'რედაქტირება',
            'Edit Email Template' => 'ელ-ფოსტების ნიმუშის რედაქტირება',
            'Name' => 'სახელი',
            'Email template content' => 'ელ-ფოსტის კონტენტის ნიმუში',
            'Save and Exit' => 'შენახვა და შემდეგ გამოსვლა',
            'Save' => 'შენახვა',
            'Cancel' => 'გაუქმება',
            'This email template does not exist' => 'ასეთი ელ-ფოსტის ნიმუში არ არსებობს',
            'Your changes to the email template <i>:name</i> have been saved.' => 'ელ-ფოსტის ნიმუშის ცვლილებები <i>:name</i> დამახსოვრებულია.',
        )
    );
