<?php

    return array(
        'emails' => array(
            'Emails' => 'E-postalar',
            'Emails plugin for Monstra' => 'Monstra için e-posta eklentisi',
            'Edit Layout' => 'Mizanpajı Düzenle',
            'Email templates' => 'E-posta şablonları',
            'Edit' => 'Düzenle',
            'Edit Email Template' => 'E-posta Şablonunu Düzenle',
            'Name' => 'Ad',
            'Email template content' => 'E-posta şablonu içeriği',
            'Save and Exit' => 'Kaydet ve Çık',
            'Save' => 'Kaydet',
            'Cancel' => 'Vazgeç',
            'This email template does not exist' => 'Bu e-posta şablonu bulunamadı',
            'Your changes to the email template <i>:name</i> have been saved.' => 'Değişiklikleriniz <i>:name</i> adlı e-posta şablonuna kaydedildi.',
        )
    );
