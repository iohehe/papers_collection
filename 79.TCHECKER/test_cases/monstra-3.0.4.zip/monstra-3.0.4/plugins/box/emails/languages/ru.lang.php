<?php

    return array(
        'emails' => array(
            'Emails' => 'Письма',
            'Emails plugin for Monstra' => 'Плагин emails для Monstra',
            'Edit Layout' => 'Редактировать Шаблон',
            'Email templates' => 'Шаблоны Писем',
            'Edit' => 'Редактировать',
            'Edit Email Template' => 'Редактировать Шаблоны Письма',
            'Name' => 'Название',
            'Email template content' => 'Конент Шаблона Письма',
            'Save and Exit' => 'Сохранить и выйты',
            'Save' => 'Сохранить',
            'Cancel' => 'Отменить',
            'This email template does not exist' => 'Этот емейл шаблон отсутствует',
            'Your changes to the email template <i>:name</i> have been saved.' => 'Ваши изменения к емейл шаблону <i>:name</i> были сохранены.',
        )
    );
