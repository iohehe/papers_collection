<?php
    return array(
        'emails' => array(
            'Emails' => 'Email',
            'Emails plugin for Monstra' => 'Email dodatak za Monstra',
            'Edit Layout' => 'Izmeni izgled',
            'Email templates' => 'Email šabloni',
            'Edit' => 'Izmeni',
            'Edit Email Template' => 'Izmeni izgled šablonu',
            'Name' => 'Ime',
            'Email template content' => 'Email sadržaj šablona',
            'Save and Exit' => 'Sačuvaj i izađi',
            'Save' => 'Sačuvaj',
            'Cancel' => 'Otkaži',
            'This email template does not exist' => 'Ovaj šablon ne postoji',
            'Your changes to the email template <i>:name</i> have been saved.' => 'Tvoje promene na šablonu <i>:name</i> su uspešno sačuvane.',
        )
    );
