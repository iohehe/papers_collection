<?php
    
    return array(
        'sitemap' => array(
            'Sitemap' => 'Mapa sajta',
        )
    );
