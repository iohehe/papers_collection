<?php

    return array(
        'sitemap' => array(
            'Sitemap' => 'Mapa witryny',
        )
    );
