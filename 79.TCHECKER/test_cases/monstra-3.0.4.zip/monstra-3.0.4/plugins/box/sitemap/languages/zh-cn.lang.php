<?php

    return array(
        'sitemap' => array(
            'Sitemap' => '网站地图',
        )
    );
