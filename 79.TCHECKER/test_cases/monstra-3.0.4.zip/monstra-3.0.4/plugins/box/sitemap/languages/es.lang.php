<?php

    return array(
        'sitemap' => array(
            'Sitemap' => 'Mapa del sitio',
        )
    );