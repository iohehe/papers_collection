<?php

    return array(
        'sitemap' => array(
            'Sitemap' => 'نقشه سایت',
        )
    );
