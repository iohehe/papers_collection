<?php

    return array(
        'sitemap' => array(
            'Sitemap' => 'Site Haritası',
        )
    );
