<?php

    return array(
        'sitemap' => array(
            'Sitemap' => 'Oldaltérkép',
        )
    );
