<?php
    
    return array(
        'sitemap' => array(
            'Sitemap' => 'Plan du site',
        )
    );