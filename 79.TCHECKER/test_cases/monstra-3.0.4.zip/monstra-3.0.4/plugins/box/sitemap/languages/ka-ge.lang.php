<?php

    return array(
        'sitemap' => array(
            'Sitemap' => 'საიტის რუქა',
        )
    );
