<?php

    return array(
        'sitemap' => array(
            'Sitemap' => 'Sitemap',
        )
    );
