<?php

    return array(
        'sitemap' => array(
            'Sitemap' => 'サイトマップ',
        )
    );
