<?php

    return array(
        'plugins' => array(
            'Plugins' => 'Plugins',
            'Name' => 'Nome',
            'Actions' => 'Ações',
            'Description' => 'Descrição',
            'Installed' => 'Instalado',
            'Install New' => 'Instalar novo',
            'Delete' => 'Deletar',
            'Delete plugin :plugin' => 'Deletar o plugin :plugin',
            'This plugins does not exist' => 'Estes plugins não existem',
            'Version' => 'Versão',
            'Author' => 'Autor',
            'Get More Plugins' => 'Ver mais plugins',
            'Install' => 'Instalar',
            'Uninstall' => 'Desinstalar',
            'README.md not found' => 'README.md not found',
        )
    );
