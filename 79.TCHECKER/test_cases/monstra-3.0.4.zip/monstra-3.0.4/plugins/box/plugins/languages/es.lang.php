<?php

    return array(
        'plugins' => array(
            'Plugins' => 'Plugins',
            'Name' => 'Nombre',
            'Actions' => 'Acciones',
            'Description' => 'Descripción',
            'Installed' => 'Instalado',
            'Install New' => 'Instalar nuevo',
            'Delete' => 'Eliminar',
            'Delete plugin :plugin' => 'Eliminar plugin: :plugin',
            'This plugin does not exist' => 'Este plugin no existe',
            'Version' => 'Versión',
            'Author' => 'Autor',
            'Get More Plugins' => 'Obtener más plugins',
            'Install' => 'Instalar',
            'Uninstall' => 'Desinstalar',
            'README.md not found' => 'README.md no encontrado',
        )
    );
