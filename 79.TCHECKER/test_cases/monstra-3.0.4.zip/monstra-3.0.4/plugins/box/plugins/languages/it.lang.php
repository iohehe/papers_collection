<?php

    return array(
        'plugins' => array(
            'Plugins' => 'Plugin',
            'Installed' => 'Installati',
            'Install New' => 'Installa nuovi',
            'Actions' => 'Azioni',
            'Name' => 'Nome',
            'Description' => 'Descrizione',
            'Delete' => 'Elimina',
            'Delete plugin :plugin' => 'Elimina plugin :plugin',
            'This plugin does not exist' => 'Tale plugin non esiste',
            'Version' => 'Versione',
            'Author' => 'Autore',
            'Get More Plugins' => 'Scarica altri plugin',
            'Install' => 'Installa',
            'Uninstall' => 'Disinstalla',
            'README.md not found' => 'README.md not found',
        )
    );
