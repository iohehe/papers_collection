<?php

    return array(
        'plugins' => array(
            'Plugins' => 'افزونه ها',
            'Name' => 'نام',
            'Actions' => 'عملیات',
            'Description' => 'توضیحات',
            'Installed' => 'نصب شده',
            'Install New' => 'نصب جدید',
            'Delete' => 'حذف',
            'Delete plugin :plugin' => 'حذف افزونه :plugin',
            'This plugin does not exist' => 'این افزونه وجود ندارد',
            'Version' => 'نسخه',
            'Author' => 'مولف',
            'Get More Plugins' => 'دریافت افزونه های بیشتر',
            'Install' => 'نصب',
            'Uninstall' => 'حذف',
            'README.md not found' => 'README.md not found',
        )
    );
