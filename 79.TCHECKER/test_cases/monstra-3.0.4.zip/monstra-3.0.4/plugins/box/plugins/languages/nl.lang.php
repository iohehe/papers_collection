<?php

    return array(
        'plugins' => array(
            'Plugins' => 'Plugins',
            'Name' => 'Naam',
            'Actions' => 'Acties',
            'Description' => 'Beschrijving',
            'Installed' => 'Geinstalleerd',
            'Install New' => 'Installeer nieuwe plugin',
            'Delete' => 'Verwijderen',
            'Delete plugin :plugin' => 'Verwijder plugin: :plugin',
            'This plugins does not exist' => 'Deze plugin bestaat niet',
            'Version' => 'Versie',
            'Author' => 'Auteur',
            'Get More Plugins' => 'Vind meer plugins',
            'Install' => 'Installeren',
            'Uninstall' => 'Deinstalleren',
            'README.md not found' => 'README.md not found',
        )
    );
