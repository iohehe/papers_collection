<?php
    
    return array(
        'plugins' => array(
            'Plugins' => 'Plugins',
            'Name' => 'Nom',
            'Actions' => 'Actions',
            'Description' => 'Description',
            'Installed' => 'Installé',
            'Install New' => 'Installer un nouveau',
            'Delete' => 'Supprimer',
            'Delete plugin :plugin' => 'Supprimer le plugin :plugin',
            'This plugin does not exist' => 'Ce plugin n\\\'existe pas',
            'Version' => 'Version',
            'Author' => 'Auteur',
            'Get More Plugins' => 'Obtenez plus de plugins',
            'Install' => 'Installer',
            'Uninstall' => 'Désinstaller',
            'README.md not found' => 'README.md not found',
        )
    );