<?php

    return array(
        'plugins' => array(
            'Plugins' => 'Plugins',
            'Name' => 'Name',
            'Actions' => 'Aktionen',
            'Description' => 'Beschreibung',
            'Installed' => 'Installiert',
            'Install New' => 'Installiere Neue',
            'Delete' => 'Löschen',
            'Delete plugin :plugin' => 'Lösche Plugin :plugin',
            'This plugins does not exist' => 'Diese Plugins existieren nicht',
            'Version' => 'Version',
            'Author' => 'Author',
            'Get More Plugins' => 'Hole weitere Plugins',
            'Install' => 'Installieren',
            'Uninstall' => 'Deinstallieren',
            'README.md not found' => 'README.md nicht gefunden',
        )
    );
