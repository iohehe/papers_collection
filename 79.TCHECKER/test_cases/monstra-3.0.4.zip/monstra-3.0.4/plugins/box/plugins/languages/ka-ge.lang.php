<?php

    return array(
        'plugins' => array(
            'Plugins' => 'პლაგინები',
            'Installed' => 'დაყენებული',
            'Install New' => 'ახალის დაყენება',
            'Actions' => 'მოქმედება',
            'Name' => 'სახელწოდება',
            'Description' => 'აღწერა',
            'Delete' => 'წაშლა',
            'Delete plugin :plugin' => ':plugin პლაგინის წაშლა',
            'This plugin does not exist' => 'ასეთი პლაგინი არ არსებობს',
            'Version' => 'ვერსია',
            'Author' => 'ავტორი',
            'Get More Plugins' => 'სხვა პლაგინების გადმოწერა',
            'Install' => 'დაყენება',
            'Uninstall' => 'წაშლა',
            'README.md not found' => 'README.md არ არის ნაპოვნი',
            'Info' => 'ინფო',
            'Upload' => 'ატვირთვა',
            'Drop File Here' => 'გადაიტანეთ ფაილი აქ',
        )
    );
