<?php
    
    return array(
        'plugins' => array(
            'Plugins' => 'Dodaci',
            'Name' => 'Ime',
            'Actions' => 'Akcije',
            'Description' => 'Opis',
            'Installed' => 'Instalirani',
            'Install New' => 'Instaliraj novi',
            'Delete' => 'Obriši',
            'Delete plugin :plugin' => 'Obriši dodatak :plugin',
            'This plugin does not exist' => 'Ovaj dodatak ne postoji',
            'Version' => 'Verzija',
            'Author' => 'Autor',
            'Get More Plugins' => 'Dodaj još dodataka',
            'Install' => 'Instaliraj',
            'Uninstall' => 'Deinstaliraj',
            'README.md not found' => 'README.md Nije nađeno',
        )
    );
