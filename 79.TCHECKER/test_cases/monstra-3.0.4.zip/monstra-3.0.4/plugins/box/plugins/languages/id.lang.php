<?php

    return array(
        'plugins' => array(
            'Plugins' => 'Plugins',
            'Name' => 'Nama',
            'Actions' => 'Tindakan',
            'Description' => 'Deskripsi',
            'Installed' => 'Terpasang',
            'Install New' => 'Pemasangan Baru',
            'Delete' => 'Hapus',
            'Delete plugin :plugin' => 'Hapus Plugin :plugin',
            'This plugins does not exist' => 'Plugin ini tidak ada',
            'Version' => 'Versi',
            'Author' => 'Penulis',
            'Get More Plugins' => 'Cari Plugins Baru',
            'Install' => 'Memasangkan',
            'Uninstall' => 'Menghapus Program',
            'README.md not found' => 'README.md not found',
        )
    );
