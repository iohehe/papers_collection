<?php

    return array(
        'plugins' => array(
            'Plugins' => 'Плагіни',
            'Installed' => 'Установлені',
            'Install New' => 'Установити нові',
            'Actions' => 'Дії',
            'Name' => 'Назва',
            'Description' => 'Опис',
            'Delete' => 'Видалити',
            'Delete plugin :plugin' => 'Видалити плагін :plugin',
            'This plugin does not exist' => 'Такого плагіна не існує',
            'Version' => 'Версія',
            'Author' => 'Автор',
            'Get More Plugins' => 'Завантажити інші плагіни',
            'Install' => 'Установити',
            'Uninstall' => 'Видалити',
            'README.md not found' => 'README.md not found',
        )
    );
