<?php

    return array(
        'menu' => array(
            'Menu' => 'Menús',
            'Menu Manager' => 'Administrador de menús',
            'Edit' => 'Editar',
            'Name' => 'Nombre',
            'Delete' => 'Eliminar',
            'Order' => 'Orden',
            'Actions' => 'Acciones',
            'Create New Item' => 'Crear nuevo item',
            'New item' => 'Nuevo item',
            'Item name' => 'Nombre del item',
            'Item order' => 'Orden del item',
            'Item target' => 'Target del item',
            'Item link' => 'Enlace del item',
            'Item category' => 'Categoría del item',
            'Save' => 'Guardar',
            'Edit item' => 'Editar item',
            'Delete item :name' => 'Eliminar item: :name',
            'Select page' => 'Seleccionar página',
            'Category' => 'Categoría',
            'Select category' => 'Seleccionar categoría',
            'Required Field' => 'Dato requerido',
            'Cancel' => 'Cancelar',
        )
    );
