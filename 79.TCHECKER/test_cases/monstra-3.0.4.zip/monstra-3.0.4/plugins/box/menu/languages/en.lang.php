<?php

    return array(
        'menu' => array(
            'Menu' => 'Menu',
            'Menu manager' => 'Menu manager',
            'Edit' => 'Edit',
            'Name' => 'Name',
            'Delete' => 'Delete',
            'Order' => 'Order',
            'Actions' => 'Actions',
            'Create New Item' => 'Create new item',
            'New item' => 'New item',
            'Item name' => 'Item name',
            'Item order' => 'Item order',
            'Item target' => 'Item target',
            'Item link' => 'Item link',
            'Item category' => 'Item category',
            'Save' => 'Save',
            'Edit item' => 'Edit item',
            'Delete item :name' => 'Delete item :name',
            'Select page' => 'Select page',
            'Category' => 'Category',
            'Select category' => 'Select category',
            'Required field' => 'Required field',
            'Cancel' => 'Cancel',
        )
    );
