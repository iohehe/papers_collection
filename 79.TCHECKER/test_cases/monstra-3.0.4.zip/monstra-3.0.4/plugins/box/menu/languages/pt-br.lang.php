<?php

    return array(
        'menu' => array(
            'Menu' => 'Menu',
            'Menu manager' => 'Gerenciador do menu',
            'Edit' => 'Editar',
            'Name' => 'Nome',
            'Delete' => 'Deletar',
            'Order' => 'Ordem',
            'Actions' => 'Ações',
            'Create New Item' => 'Criar novo item',
            'New item' => 'Novo item',
            'Item name' => 'Nome do item',
            'Item order' => 'ordem do item',
            'Item target' => 'Target do item (atributo HTML)',
            'Item link' => 'Link do item',
            'Item category' => 'Categoria do item',
            'Save' => 'Salvar',
            'Edit item' => 'Editar item',
            'Delete item :name' => 'Deletar o item :name',
            'Select page' => 'Selecionar página',
            'Category' => 'Categoria',
            'Select category' => 'Selecionar categoria',
            'Required field' => 'Campo requerido',
            'Cancel' => 'Cancel',
        )
    );
