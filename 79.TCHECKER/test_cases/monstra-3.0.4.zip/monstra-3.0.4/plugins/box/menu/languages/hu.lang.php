<?php

    return array(
        'menu' => array(
            'Menu' => 'Menü',
            'Menu manager' => 'Menükezelő',
            'Edit' => 'Szerkeszt',
            'Name' => 'Név',
            'Delete' => 'Töröl',
            'Order' => 'Rendezés',
            'Actions' => 'Műveletek',
            'Create New Item' => 'Új menü készítése',
            'New item' => 'Új menü',
            'Item name' => 'Menü neve',
            'Item order' => 'Menü rendezés',
            'Item target' => 'Menü célpont',
            'Item link' => 'Menü link',
            'Item category' => 'Menü kategória',
            'Save' => 'Mentés',
            'Edit item' => 'Menü szerkesztése',
            'Delete item :name' => 'Menü törlése :name',
            'Select page' => 'Válassza ki az oldalt',
            'Category' => 'Kategória',
            'Select category' => 'Válassza ki a kategóriát',
            'Required field' => 'Kötelező mező',
            'Cancel' => 'Cancel',
        )
    );
