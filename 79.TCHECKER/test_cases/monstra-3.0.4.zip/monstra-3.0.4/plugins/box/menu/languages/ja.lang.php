<?php

    return array(
        'menu' => array(
            'Menu' => 'メニュー',
            'Menu manager' => 'メニューの管理',
            'Edit' => '編集',
            'Name' => '名前',
            'Delete' => '削除',
            'Order' => '順序',
            'Actions' => '操作',
            'Create New Item' => '新規アイテムを作成',
            'New item' => '新規アイテム',
            'Item name' => 'アイテムの名前',
            'Item order' => 'アイテムの順序',
            'Item target' => 'アイテムのターゲット',
            'Item link' => 'アイテムのリンク先',
            'Item category' => 'アイテムのカテゴリ',
            'Save' => '保存',
            'Edit item' => 'アイテムの編集',
            'Delete item :name' => 'アイテムの削除 :name',
            'Select page' => 'ページの選択',
            'Category' => 'カテゴリ',
            'Select category' => 'カテゴリの選択',
            'Required field' => '必須項目',
        )
    );
