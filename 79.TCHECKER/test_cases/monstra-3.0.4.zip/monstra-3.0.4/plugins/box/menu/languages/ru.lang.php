<?php

    return array(
        'menu' => array(
            'Menu' => 'Меню',
            'Menu manager' => 'Менеджер меню',
            'Edit' => 'Редактировать',
            'Name' => 'Название',
            'Delete' => 'Удалить',
            'Order' => 'Порядок',
            'Actions' => 'Действия',
            'Create New Item' => 'Создать новый пункт меню',
            'New item' => 'Новый пункт меню',
            'Item name' => 'Название',
            'Item order' => 'Порядок',
            'Item target' => 'Цель',
            'Item link' => 'Ссылка',
            'Item category' => 'Категория',
            'Save' => 'Сохранить',
            'Edit item' => 'Редактирование пункта меню',
            'Delete item :name' => 'Удалить пункт меню :name',
            'Select page' => 'Выбрать страницу',
            'Category' => 'Категория',
            'Select category' => 'Выбрать категорию',
            'Required field' => 'Обязательное поле',
            'Cancel' => 'Отмена',
        )
    );
