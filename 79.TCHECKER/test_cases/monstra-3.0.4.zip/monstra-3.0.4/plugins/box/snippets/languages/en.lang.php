<?php

    return array(
        'snippets' => array(
            'Snippets' => 'Snippets',
            'Snippets manager' => 'Snippets manager',
            'Actions' => 'Actions',
            'Delete' => 'Delete',
            'Edit' => 'Edit',
            'Name' => 'Name',
            'Create New Snippet' => 'Create New Snippet',
            'New Snippet' => 'New Snippet',
            'Edit Snippet' => 'Edit Snippet',
            'Save' => 'Save',
            'Save and Exit' => 'Save and Exit',
            'This snippet already exists' => 'This snippet already exists',
            'This snippet does not exist' => 'This snippet does not exist',
            'Delete snippet: :snippet' => 'Delete snippet: :snippet',
            'Snippet content' => 'Snippet content',
            'Snippet <i>:name</i> deleted' => 'Snippet <i>:name</i> deleted',
            'Your changes to the snippet <i>:name</i> have been saved.' => 'Your changes to the snippet <i>:name</i> have been saved.',
            'Delete snippet: :snippet' => 'Delete snippet: :snippet',
            'Required field' => 'Required field',
            'View Embed Code' => 'View Embed Code',
            'Embed Code' => 'Embed Code',
            'Shortcode' => 'Shortcode',
            'PHP Code' => 'PHP Code',
            'Cancel' => 'Cancel',
        )
    );
