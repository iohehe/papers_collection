<?php

    return array(
        'Editor' => array(
            'Editor' => 'Redaktorius',
            'Editor plugin' => 'Redaktoriaus papildinys',
        )
    );
