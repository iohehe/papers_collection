<?php

    return array(
        'Editor' => array(
            'Editor' => 'Editor',
            'Editor plugin' => 'Plugin do editor',
        )
    );
