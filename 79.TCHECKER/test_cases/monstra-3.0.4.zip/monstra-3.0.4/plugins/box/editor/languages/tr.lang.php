<?php

    return array(
        'Editor' => array(
            'Editor' => 'Düzenleyici',
            'Editor plugin' => 'Düzenleyici eklentisi',
        )
    );
