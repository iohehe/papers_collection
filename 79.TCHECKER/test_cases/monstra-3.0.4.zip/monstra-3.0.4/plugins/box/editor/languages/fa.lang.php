<?php

    return array(
        'Editor' => array(
            'Editor' => 'ویرایشگر',
            'Editor plugin' => 'پلاگین ویرایشگر',  
        )
    );
