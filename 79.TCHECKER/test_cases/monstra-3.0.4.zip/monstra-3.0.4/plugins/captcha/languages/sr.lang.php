<?php

    return array(
        'captcha' => array(
            'Captcha' => 'Captcha',
            'Captcha plugin for Monstra' => 'Captcha dodatak za Monstra',
            'Captcha code is wrong' => 'Captcha Kod je pogrešan',
        ) 
    );
