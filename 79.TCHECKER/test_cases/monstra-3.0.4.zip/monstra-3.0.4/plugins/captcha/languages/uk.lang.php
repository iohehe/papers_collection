<?php

    return array(
        'captcha' => array(
            'Captcha' => 'Каптча',
            'Captcha plugin for Monstra' => 'Каптча плагін для Monstra',
            'Captcha code is wrong' => 'Код каптчі невірний',
        )
    );
