<?php

    return array(
        'captcha' => array(
            'Captcha' => '验证码',
            'Captcha plugin for Monstra' => 'Monstra 验证码插件',
            'Captcha code is wrong' => '验证码错误',
        )
    );
