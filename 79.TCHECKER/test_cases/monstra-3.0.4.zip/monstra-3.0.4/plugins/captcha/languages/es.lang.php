<?php

    return array(
        'captcha' => array(
            'Captcha' => 'Captcha',
            'Captcha plugin for Monstra' => 'Captcha plugin for Monstra',
            'Captcha code is wrong' => 'El código captcha es incorrecto',
        )
    );
