<?php

    return array(
        'captcha' => array(
            'Captcha' => 'Saugos kodas',
            'Captcha plugin for Monstra' => 'Saugos kodo papildinys',
            'Captcha code is wrong' => 'Saugos kodas yra neteisingas',
        )
    );
