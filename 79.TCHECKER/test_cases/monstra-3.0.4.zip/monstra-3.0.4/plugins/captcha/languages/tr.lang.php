<?php

    return array(
        'captcha' => array(
            'Captcha' => 'Captcha/Doğrulama',
            'Captcha plugin for Monstra' => 'Monstra için captcha/doğrulama eklentisi',
            'Captcha code is wrong' => 'Doğrulama kodu yanlış',
        )
    );
