<?php

    return array(
        'captcha' => array(
            'Captcha' => 'Captcha',
            'Captcha plugin for Monstra' => 'Plugin Captcha pour Monstra',
            'Captcha code is wrong' => 'Le code Captcha est erroné',
        ) 
    );