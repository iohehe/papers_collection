<?php

    return array(
        'captcha' => array(
            'Captcha' => 'Captcha',
            'Captcha plugin for Monstra' => 'Captcha Plugin für Monstra',
            'Captcha code is wrong' => 'Captcha Code ist falsch',
        )
    );
