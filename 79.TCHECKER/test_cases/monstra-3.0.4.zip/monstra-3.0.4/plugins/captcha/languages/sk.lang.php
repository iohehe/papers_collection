<?php

    return array(
        'captcha' => array(
            'Captcha' => 'Captcha',
            'Captcha plugin for Monstra' => 'Captcha plugin pre Monstra',
            'Captcha code is wrong' => 'Captcha kód je nesprávny',
        )
    );
