<?php

    return array(
        'captcha' => array(
            'Captcha' => 'Captcha',
            'Captcha plugin for Monstra' => 'Captcha პლაგინი Monstra-თვის',
            'Captcha code is wrong' => 'Captcha-ზე პასუხი არასწორია!',
        )
    );
