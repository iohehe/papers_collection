<?php

    return array(
        'sandbox' => array(
            'Sandbox' => 'Sandbox',
            'Sandbox plugin for Monstra' => 'Sandbox Plugin voor Monstra',
            'Sandbox template' => 'Sandbox Template',
            'Save' => 'Opslaan',
        )
    );
