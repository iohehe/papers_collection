<?php

    return array(
        'sandbox' => array(
            'Sandbox' => 'سندباکس',
            'Sandbox plugin for Monstra' => 'پلاگین سندباکس برای مونسترا',
            'Sandbox template' => 'قالب سندباکس',
            'Save' => 'ذخیره',
        )
    );
