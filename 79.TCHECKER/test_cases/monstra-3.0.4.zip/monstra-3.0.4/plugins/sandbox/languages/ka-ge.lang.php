<?php

    return array(
        'sandbox' => array(
            'Sandbox' => 'Sandbox',
            'Sandbox plugin for Monstra' => 'Sandbox-ის პლაგინი Monstra-თვის',
            'Sandbox template' => 'Sandbox-ის ნიმუში',
            'Save' => 'შენახვა',
        )
    );
