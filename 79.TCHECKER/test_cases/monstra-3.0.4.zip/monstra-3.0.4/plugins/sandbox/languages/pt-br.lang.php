<?php

    return array(
        'sandbox' => array(
            'Sandbox' => 'Caixa de Areia',
            'Sandbox plugin for Monstra' => 'Plugin Caixa de Areia para o Monstra CMS',
            'Sandbox template' => 'Template da caixa de areia',
            'Save' => 'Salvar',
        )
    );
