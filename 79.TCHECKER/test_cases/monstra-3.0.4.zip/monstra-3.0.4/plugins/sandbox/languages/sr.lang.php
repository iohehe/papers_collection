<?php

    return array(
        'sandbox' => array(
            'Sandbox' => 'Sandbox',
            'Sandbox plugin for Monstra' => 'Sandbox dodatak za Monstra',
            'Sandbox template' => 'Sandbox šablon',
            'Save' => 'Sačuvaj',
        ) 
    );
