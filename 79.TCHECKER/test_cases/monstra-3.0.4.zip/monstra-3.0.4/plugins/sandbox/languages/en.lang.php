<?php

    return array(
        'sandbox' => array(
            'Sandbox' => 'Sandbox',
            'Sandbox plugin for Monstra' => 'Sandbox plugin for Monstra',
            'Sandbox template' => 'Sandbox template',
            'Save' => 'Save',
        )
    );
