<?php

    return array(
        'sandbox' => array(
            'Sandbox' => 'Пісочниця',
            'Sandbox plugin for Monstra' => 'Плагін пісочниця для Monstra',
            'Sandbox template' => 'Шаблон пісочниці',
            'Save' => 'Зберегти',
        )
    );
