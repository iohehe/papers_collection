<a href="<?php echo Site::url(); ?>/sitemap"><?php echo __('Sitemap', 'sitemap'); ?></a>
