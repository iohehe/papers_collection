# Gelato Library

Gelato is a PHP5 library for kickass Web Applications.

## Links
- [Site](http://gelato.monstra.org)
- [Github Repository](https://github.com/MonstrLab/gelato)

Copyright (C) 2013 Romanenko Sergey / Awilum [awilum@msn.com]