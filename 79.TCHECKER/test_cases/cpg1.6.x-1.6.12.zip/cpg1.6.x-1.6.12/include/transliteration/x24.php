<?php
/*************************
  Coppermine Photo Gallery
  ************************
  Copyright (c) 2003-2016 Coppermine Dev Team
  v1.0 originally written by Gregory Demar

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License version 3
  as published by the Free Software Foundation.

  ********************************************
  Coppermine version: 1.6.03
  $HeadURL$
**********************************************/

$base = array(
  0x00 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x10 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x20 => '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x30 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x40 => '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL,
  0x50 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x60 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x70 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x80 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0x90 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xA0 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xB0 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xC0 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xD0 => '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '',
  0xE0 => '', '', '', '', '', '', '', '', '', '', '', NULL, NULL, NULL, NULL, NULL,
  0xF0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
);
