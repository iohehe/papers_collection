<?php
/*************************
  Coppermine Photo Gallery
  ************************
  Copyright (c) 2003-2016 Coppermine Dev Team
  v1.0 originally written by Gregory Demar

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License version 3
  as published by the Free Software Foundation.

  ********************************************
  Coppermine version: 1.6.03
  $HeadURL$
**********************************************/

if (!defined('IN_COPPERMINE')) die('Not in Coppermine...');

$lang_plugin_sample['config_name'] = 'Per exemple WordPress';
$lang_plugin_sample['config_description'] = 'Per exemple WordPress. No fa res particularment útil-pensat per mostrar què poden fer els plugins i com programar-los. En activar-lo mostrarà un text d\'exemple en vermell.';
$lang_plugin_sample['plugin_documentation'] = 'Documentació del Plugin';
$lang_plugin_sample['plugin_support'] = 'Suport del Plugin';
$lang_plugin_sample['install_explain'] = 'Introdueix el nom d\'usuari (\'foo\') i contrasenya (\'bar\') per instal·lar';
$lang_plugin_sample['install_username'] = 'Usuari';
$lang_plugin_sample['install_password'] = 'Contrasenya';
$lang_plugin_sample['output'] = 'Aquest és el text retornat pel connector d\'exemple';

//EOF