<?php
/**
 * Coppermine Photo Gallery
 *
 * v1.0 originally written by Gregory Demar
 *
 * @copyright  Copyright (c) 2003-2018 Coppermine Dev Team
 * @license    GNU General Public License version 3 or later; see LICENSE
 *
 * tools/del_orphans/lang/english.php
 * @since  1.6.06
 */

$lang['searching_orphans'] = 'Searching for orphan comments, please wait...';