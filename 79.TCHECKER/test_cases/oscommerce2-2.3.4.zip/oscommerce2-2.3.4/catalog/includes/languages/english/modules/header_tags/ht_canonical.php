<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2012 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_CANONICAL_TITLE', 'Canonical Header Links');
  define('MODULE_HEADER_TAGS_CANONICAL_DESCRIPTION', 'Add header canonical links to category and product pages');
?>
