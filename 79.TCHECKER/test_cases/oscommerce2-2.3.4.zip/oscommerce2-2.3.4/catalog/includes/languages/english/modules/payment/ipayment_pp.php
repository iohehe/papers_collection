<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_IPAYMENT_PP_TEXT_TITLE', 'iPayment (Prepaid)');
  define('MODULE_PAYMENT_IPAYMENT_PP_TEXT_PUBLIC_TITLE', 'Prepaid (Paysafecard)');
  define('MODULE_PAYMENT_IPAYMENT_PP_TEXT_DESCRIPTION', '<img src="images/icon_popup.gif" border="0">&nbsp;<a href="https://www.ipayment.de" target="_blank" style="text-decoration: underline; font-weight: bold;">Visit iPayment Website</a>');
  define('MODULE_PAYMENT_IPAYMENT_PP_ERROR_HEADING', 'There has been an error processing your prepaid card');
  define('MODULE_PAYMENT_IPAYMENT_PP_ERROR_MESSAGE', 'Please check your prepaid card details!');
?>
