Dear {F_NAME},
Your friend, {S_NAME} ({S_EMAIL}), has forwarded you an auction from {SITENAME}

Auction Title: {TITLE}
Comments: {S_COMMENT}

Check it out: {URL}