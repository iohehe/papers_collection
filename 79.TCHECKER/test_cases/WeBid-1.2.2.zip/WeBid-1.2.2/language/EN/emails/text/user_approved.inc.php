Hello {C_NAME},

This e-mail is to confirm that your registration at {SITENAME} has been approved!
You can now login in to your account and start selling and/or bidding. Thanks for joining us!

Ready To Start Looking?

Visit us at {SITE_URL}