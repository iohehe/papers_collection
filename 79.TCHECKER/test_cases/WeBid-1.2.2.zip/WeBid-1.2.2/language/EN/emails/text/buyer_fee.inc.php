Dear {C_NAME},

This is an invoice for the payment of the buying fee of {ITEM_NAME}.

Total payable: {BALANCE}

Please click on the link below to access to the payment page:
{LINK}

All activity on your site will be suspended until this is paid