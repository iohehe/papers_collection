Dear {W_NAME},

You have won the following auction on {SITENAME}

Auction data

Title: {A_TITLE}
Description: {A_DESCRIPTION}

Your bid: {A_CURRENTBID} ({W_WANTED} items)
You got: {W_GOT} items
Auction End Date: {A_ENDS}
URL: {A_URL}

Sellers Info

{S_NICK}
{S_EMAIL}
Seller's payment details:
{S_PAYMENT}


If you have received this message in error, please reply to this email,
write to {ADMINEMAIL}, or visit {SITENAME} at {SITE_URL}.
