Dear {REALNAME},
This is an automatic response from Your Item Watch.
Someone has bid on an item you have added to your item watch list.

Auction Title: {TITLE}
Current Bid: {BID}

Auction URL: {AUCTION_URL}