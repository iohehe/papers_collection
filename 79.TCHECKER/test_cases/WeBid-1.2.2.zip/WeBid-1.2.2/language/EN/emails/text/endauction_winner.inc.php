Dear {S_NAME},
Congratulations your item has just sold!

Below are the details.

Auction title: {A_TITLE}
Sale price: {A_CURRENTBID}
Quantity: {A_QTY}
End date: {A_ENDS}
Auction URL: {A_URL}

Goto My {SITENAME}: {SITE_URL}user_menu.php

Buyer's Information
{B_REPORT}