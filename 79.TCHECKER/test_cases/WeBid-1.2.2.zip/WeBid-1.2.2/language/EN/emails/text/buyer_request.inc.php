User {NAME} ({NICK}),
Owner of a buyer account asked to switch to a seller account.

User's details

User ID: {ID}
User Name: {NAME}
User Nick: {NICK}
User E-mail: {EMAIL}