Hi {REALNAME},<br>
As you requested, we have created a new password for your account.<br>
<br>
Your new password: {NEWPASS}<br>
<br>
Use it to login to {SITENAME} and remember to change it to the one you can remember.