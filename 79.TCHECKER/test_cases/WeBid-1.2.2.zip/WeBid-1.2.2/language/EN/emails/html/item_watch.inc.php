Dear {REALNAME},<br>
<br>
This is an automatic response from Your Item Watch. <br>
Someone has bid on an item you have added to your item watch list.<br>
<br>
Auction Title: {TITLE}<br>
<br>
Current Bid: {BID}<br>
<br>
Auction URL: <a href="{AUCTION_URL}">{AUCTION_URL}</a>