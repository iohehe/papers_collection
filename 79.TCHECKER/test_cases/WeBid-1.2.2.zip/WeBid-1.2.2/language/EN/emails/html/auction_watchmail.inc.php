<table border="0" width="100%">
	<tr>
		<td colspan="2" height="35"><div style="font-size: 14px; font-weight: bold;">Your Auction Watch Is Here From {SITENAME}!</div></td>
	</tr>
	<tr>
		<td colspan="2" style="font-size: 12px;">Hello <b>{REALNAME}</b>,</td>
	</tr>
	<tr>
		<td colspan="2" height="50" style="font-size: 12px; padding-right: 6px;">
			This is your auction watch you've requested.  The following auction has opened matching your keyword(s): <b>{KWORD}</b>
		</td>
	</tr>
	<tr>
		<td width="55%" rowspan="2" valign="top"><br />
		<table border="0" width="100%">
			<tr>
				<td style="font-size: 12px; padding-bottom: 7px; padding-top: 5px;"><b>Auction:</b>&nbsp;{TITLE}</td>
			</tr>
			<tr>
				<td style="font-size: 12px;"><b>Auction URL:</b>&nbsp;<a href="{URL}">{URL}</a></td>
			</tr>
		</table>
		</td>
		<td width="34%" style="font-size: 12px;">&nbsp;</td>
	</tr>
	<tr>
		<td width="34%" height="176" valign="top">&nbsp;
		</td>
	</tr>
</table>