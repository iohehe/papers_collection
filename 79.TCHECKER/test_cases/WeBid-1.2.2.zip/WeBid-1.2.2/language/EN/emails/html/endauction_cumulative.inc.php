Dear {S_NAME},<br>
<br>
The following auctions you posted at <a href="{SITE_URL}">{SITENAME}</a> closed yesterday.<br>
<br>
{REPORT}
<br>
<br>
{REPORT_WINNER}<br>
<br>
If you have received this message in error, please reply to this email,
write to <a href="mailto:{ADMINMAIL}">{ADMINMAIL}</a>, or visit {SITENAME} at <a href="{SITE_URL}">{SITE_URL}</a>.