Dear {W_NAME},<br>
<br>
You have won the following auction on <a href="{SITE_URL}">{SITENAME}</a> <br>
<br>
Auction data<br>
------------------------------------<br>
Title: {A_TITLE}<br>
Description: {A_DESCRIPTION}<br>
<br>
Your bid: {A_CURRENTBID} ({W_WANTED} items)<br>
You got: {W_GOT} items<br>
Auction End Date: {A_ENDS}<br>
URL: <a href="{A_URL}">{A_URL}</a><br>
<br>
=============<br>
SELLER'S INFO<br>
=============<br>
<br>
{S_NICK}<br>
<a href="mailto:{S_EMAIL}">{S_EMAIL}</a><br>
Seller's payment details:<br>
{S_PAYMENT}<br>
<br>
<br>
If you have received this message in error, please reply to this email,<br>
write to <a href="mailto:{ADMINEMAIL}">{ADMINEMAIL}</a>, or visit <a href="{SITE_URL}">{SITENAME}</a> at <a href="{SITE_URL}">{SITE_URL}</a>.