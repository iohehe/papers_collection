var lang = { 
added_to_cart:"Προσθήκη στο Καλάθι",
error_to_cart:"Πρόβλημα με το καλάθι! Δοκιμάστε ξανά!",
no_products:"Δεν υπάρχουν στοιχεία",
confirm_clear_cart:"Είστε βέβαιοι ότι θέλετε να αδειάσετε το καλάθι;",
cleared_cart:"Το καλάθι σας είναι άδειο",
are_you_sure:"Είσαι σίγουρος;",
yes:" ότι",
no:"δεν",
clear_all:"σαφής",
checkout:"πληρωμή",
remove_from_cart:"Διαγράφονται από το καλάθι",
enter_valid_email:"Παρακαλώ εισάγετε μια έγκυρη διεύθυνση ηλεκτρονικού ταχυδρομείου",
discountCodeInvalid: "Ο κωδικός δεν είναι έγκυρος"
};
