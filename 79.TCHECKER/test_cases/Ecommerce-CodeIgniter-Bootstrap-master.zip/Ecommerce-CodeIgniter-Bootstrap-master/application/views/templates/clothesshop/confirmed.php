<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="container">
    <h1><?= lang('order_confirmed') ?></h1>
</div>